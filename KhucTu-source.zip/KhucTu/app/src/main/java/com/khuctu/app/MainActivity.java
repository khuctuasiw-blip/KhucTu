package com.khuctu.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    SharedPreferences sp;
    TextView status;
    Button toggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(FcmService.PREFS, 0);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);

        TextView title = new TextView(this);
        title.setText("KhucTu - Reconnect FCM");
        title.setTextSize(24);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("\nChu kỳ kiểm tra / kết nối lại FCM:");
        root.addView(hint);

        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        final int[] opts = {5, 10, 15};
        for (int m : opts) {
            RadioButton rb = new RadioButton(this);
            rb.setText(m + " phút");
            rb.setId(m);
            rg.addView(rb);
        }
        rg.check(sp.getInt("min", 5));
        rg.setOnCheckedChangeListener((g, id) -> {
            sp.edit().putInt("min", id).apply();
            if (sp.getBoolean("on", false)) startSvc();
        });
        root.addView(rg);

        toggle = new Button(this);
        toggle.setOnClickListener(v -> {
            boolean on = !sp.getBoolean("on", false);
            sp.edit().putBoolean("on", on).apply();
            if (on) startSvc(); else stopService(new Intent(this, FcmService.class));
            refresh();
        });
        root.addView(toggle);

        Button batt = new Button(this);
        batt.setText("Tắt tối ưu pin cho KhucTu");
        batt.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Throwable t) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        root.addView(batt);

        status = new TextView(this);
        status.setPadding(0, p, 0, 0);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("\nKiểm tra trạng thái FCM: mở Điện thoại, bấm *#*#426#*#*");
        root.addView(note);

        setContentView(root);
    }

    void startSvc() { startForegroundService(new Intent(this, FcmService.class)); }

    @Override protected void onResume() { super.onResume(); refresh(); }

    void refresh() {
        boolean on = sp.getBoolean("on", false);
        toggle.setText(on ? "TẮT" : "BẬT");
        long last = sp.getLong("last", 0);
        status.setText("Trạng thái: " + (on ? "đang chạy" : "đã tắt") +
                (last > 0 ? "\nLần reconnect gần nhất: " + DateFormat.getTimeInstance().format(new Date(last)) : ""));
    }
}
