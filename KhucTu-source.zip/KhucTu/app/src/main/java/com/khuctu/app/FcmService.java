package com.khuctu.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;

public class FcmService extends Service {
    static final String PREFS = "khuctu";
    static final String[] ACTIONS = {
        "com.google.android.intent.action.GCM_RECONNECT",
        "com.google.android.intent.action.GTALK_HEARTBEAT",
        "com.google.android.intent.action.MCS_HEARTBEAT"
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createForeground();
        ping();
        schedule();
        return START_STICKY;
    }

    void ping() {
        for (String a : ACTIONS) {
            try {
                Intent i = new Intent(a).setPackage("com.google.android.gms");
                sendBroadcast(i);
            } catch (Throwable ignored) {}
        }
        getSharedPreferences(PREFS, 0).edit().putLong("last", System.currentTimeMillis()).apply();
    }

    void schedule() {
        int min = getSharedPreferences(PREFS, 0).getInt("min", 5);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getService(this, 1, new Intent(this, FcmService.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + min * 60_000L, pi);
    }

    void createForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("kt", "KhucTu", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "kt")
                .setContentTitle("KhucTu đang giữ kết nối FCM")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    @Override public void onDestroy() {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        am.cancel(PendingIntent.getService(this, 1, new Intent(this, FcmService.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
