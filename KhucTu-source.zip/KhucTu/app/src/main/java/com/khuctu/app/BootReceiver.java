package com.khuctu.app;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (c.getSharedPreferences(FcmService.PREFS, 0).getBoolean("on", false))
            c.startForegroundService(new Intent(c, FcmService.class));
    }
}
